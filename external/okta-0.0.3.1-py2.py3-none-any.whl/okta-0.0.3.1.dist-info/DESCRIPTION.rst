oktasdk-python
=======================

This SDK allows managing an Okta instance via Python.

