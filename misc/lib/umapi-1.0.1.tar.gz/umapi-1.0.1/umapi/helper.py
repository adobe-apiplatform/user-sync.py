def iter_paginate(call, org_id, max_pages=0):
    page = 0
    while True:
        res = call(org_id, page)
        if 'groups' in res:
            res_type = 'groups'
        else:
            res_type = 'users'
        for res_item in res[res_type]:
            yield res_item

        page += 1
        if max_pages and max_pages >= page:
            break

        if 'lastPage' in res and res['lastPage']:
            break

def paginate(call, org_id, max_pages=0):
    return list(iter_paginate(call, org_id, max_pages))
