class Credentials:

    types = {
        'username': str,
        'password': str
    }

    def __init__(self):

        # a user&#39;s login name
        self.username = None  # str

        # a user&#39;s password
        self.password = None  # str
