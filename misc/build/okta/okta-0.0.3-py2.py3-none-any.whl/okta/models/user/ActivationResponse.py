class ActivationResponse:

    types = {
        'activationUrl': str
    }

    def __init__(self):

        self.activationUrl = None  # str
