class AppLinks:

    types = {
        'login': bool
    }

    def __init__(self):

        self.login = None  # bool
